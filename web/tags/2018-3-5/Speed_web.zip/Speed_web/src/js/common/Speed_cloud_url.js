

var Speed_cloud_url = {
    "switch":"test",//formal
    "api":"123",
}

if (Speed_cloud_url.switch  === 'test') {
    Speed_cloud_url.api = 'https://www.nicholeyep.com:8455/speedapi/'
}else{
    Speed_cloud_url.api = '2'
}
var Speed_cloud_param = {
    
}
console.log(Speed_cloud_url.api)
