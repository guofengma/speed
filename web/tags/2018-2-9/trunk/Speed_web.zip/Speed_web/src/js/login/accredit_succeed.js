(function(){

    // 完善个人信息
    $('.perfection_personal_info').click(function(){
        window.location.href = './../../html/login/login_info.html';
    })

    
})()