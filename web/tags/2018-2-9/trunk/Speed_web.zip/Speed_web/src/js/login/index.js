(function(){
    $('.login_select_wx').click(function(){
        // android.hello('123123');
        window.location.href = './src/html/login/accredit_succeed.html'
    })
    $('.login_select_phone').click(function(){
        window.location.href = './src/html/login/phone_login.html'
    })
})()